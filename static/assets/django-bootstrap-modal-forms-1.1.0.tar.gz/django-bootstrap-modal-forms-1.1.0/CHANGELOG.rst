=========
Changelog
=========

1.1.0 (2018-08-11)
==================

- fix redirection to success_url
- update README.rst

1.0 (2018-05-28)
================

Initial release.
